package com.springtraining.ciWithListCollection;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
@ComponentScan("com.springtraining.ciWithListCollection")
public class ApplicationConfig {

    @Bean
    public Question getQuestion() {
        List<String> answers = new ArrayList<String>(Arrays.asList("Java is a programming language", "Java is a Platform", "Java is an Island of Indonasia"));
        return new Question(111, "What is java?", answers);
    }

    @Bean("ans1")
    public Answer getAnswerOne() {
        Answer answer = new Answer(1, "Java is a programming language", "John");
        return answer;
    }

    @Bean("ans2")
    public Answer getAnswerTwo() {
        Answer answer = new Answer(2, "Java is a Platform", "Ravi");
        return answer;
    }

    @Bean
    public Question2 getQuestion2(@Qualifier("ans1") final Answer answerOne, @Qualifier("ans2") final Answer answerTwo) {
        List<Answer> answers = new ArrayList<Answer>() {
            {
                add(answerOne);
                add(answerTwo);
            }
        };
        Question2 question2 = new Question2(111, "What is java", answers);
        return question2;
    }


}
