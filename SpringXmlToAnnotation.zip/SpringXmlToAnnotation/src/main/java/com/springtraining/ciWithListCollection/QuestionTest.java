package com.springtraining.ciWithListCollection;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class QuestionTest {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        Question q = context.getBean(Question.class);
        q.displayInfo();
        Question2 q2 = context.getBean(Question2.class);
        q2.displayInfo();
        context.close();

    }

}
